CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `drivers`
--

DROP TABLE IF EXISTS `drivers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `drivers` (
  `driverId` int NOT NULL,
  `licenseNumber` varchar(45) DEFAULT NULL,
  `dateHired` varchar(45) DEFAULT NULL,
  `rating` double DEFAULT NULL,
  `vehicleMake` varchar(45) DEFAULT NULL,
  `vehicleModel` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`driverId`),
  UNIQUE KEY `driverId_UNIQUE` (`driverId`),
  CONSTRAINT `drivers_ibfk_1` FOREIGN KEY (`driverId`) REFERENCES `deliveries` (`driverId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `drivers`
--

LOCK TABLES `drivers` WRITE;
/*!40000 ALTER TABLE `drivers` DISABLE KEYS */;
INSERT INTO `drivers` VALUES (1,'5733407877','September 21st, 2020',3,'ipsum','posuere'),(2,'6693444064','September 27th, 2019',4,'ac','sem'),(3,'5136688075','July 1st, 2020',5,'nisi','erat'),(4,'1561037621','January 10th, 2021',4,'bibendum','enim'),(5,'6588659818','February 23rd, 2020',5,'Aliquam','mauris.'),(6,'7311221655','March 28th, 2020',4,'cursus','ac'),(7,'8293417696','September 7th, 2020',5,'convallis,','orci'),(8,'4403259138','September 21st, 2020',1,'Donec','nulla'),(9,'1331589015','June 28th, 2019',4,'malesuada','lorem'),(10,'6439189832','September 2nd, 2019',2,'rutrum','non,'),(11,'3396714305','May 13th, 2019',1,'purus.','eu,'),(12,'2277098195','April 8th, 2021',4,'molestie','dolor.'),(13,'1082457601','April 8th, 2020',5,'massa','est,'),(14,'1279906758','February 14th, 2021',1,'augue.','nibh'),(15,'8261023228','March 31st, 2021',5,'in,','Duis'),(16,'2663589049','May 29th, 2020',3,'neque','mi'),(17,'7646837350','November 1st, 2020',5,'nibh','est'),(18,'4975783198','February 19th, 2021',5,'ornare.','libero'),(19,'1132850168','May 22nd, 2019',4,'accumsan','mattis'),(20,'4768555017','June 26th, 2019',3,'litora','bibendum'),(21,'4265489014','October 14th, 2020',1,'scelerisque','Maecenas'),(22,'2378467477','January 2nd, 2020',1,'ut','arcu'),(23,'1591220775','August 12th, 2020',2,'adipiscing,','vel,'),(24,'1044704013','June 19th, 2020',4,'Donec','sodales'),(25,'3973893231','April 11th, 2021',2,'egestas','dolor'),(26,'3100244207','July 27th, 2019',2,'amet','diam'),(27,'2929759490','March 17th, 2021',2,'purus','magna.'),(28,'6049030872','April 7th, 2020',1,'consequat','sapien'),(29,'9515890081','June 11th, 2020',3,'vehicula','nisl'),(30,'2116736860','April 8th, 2021',1,'faucibus','in'),(31,'8211289097','December 26th, 2020',1,'nec','Cras'),(32,'1442923140','February 19th, 2020',3,'elit.','varius'),(33,'4640734145','October 14th, 2020',5,'Etiam','erat'),(34,'1646453959','April 2nd, 2020',1,'hendrerit','enim'),(35,'7232148323','November 30th, 2020',4,'sagittis.','massa.'),(36,'6950480234','November 29th, 2020',3,'et,','imperdiet'),(37,'9823593908','May 28th, 2019',3,'rutrum','mollis.'),(38,'2317311033','May 18th, 2019',4,'Aliquam','sociis'),(39,'9601396759','June 13th, 2019',2,'Cras','consectetuer'),(40,'3671970461','October 6th, 2020',1,'ac','nisl'),(41,'7686984495','December 5th, 2019',4,'pede.','enim.'),(42,'9640665702','January 9th, 2020',2,'eleifend','magna.'),(43,'1825660763','April 5th, 2020',1,'montes,','ipsum'),(44,'2656920026','January 2nd, 2020',1,'vehicula','sollicitudin'),(45,'6691055851','August 28th, 2020',5,'sit','faucibus'),(46,'9911977481','May 8th, 2019',3,'non','porttitor'),(47,'2718580340','June 30th, 2020',5,'Duis','aliquet,'),(48,'4760918030','April 10th, 2020',2,'urna.','Suspendisse'),(49,'9984859324','April 22nd, 2020',5,'velit.','nulla'),(50,'7561535740','June 15th, 2019',2,'Nunc','adipiscing,'),(51,'3129633515','June 2nd, 2019',4,'nascetur','eu'),(52,'1449020279','April 6th, 2021',1,'hendrerit','Aliquam'),(53,'1624722224','March 18th, 2021',5,'a,','rutrum'),(54,'9824309769','February 14th, 2021',5,'tempor','ad'),(55,'3091423980','October 1st, 2019',5,'ornare.','ipsum'),(56,'2633229557','June 23rd, 2019',3,'id,','eget,'),(57,'7669012115','May 10th, 2020',3,'blandit','at'),(58,'8630264826','November 20th, 2019',3,'enim.','nisi'),(59,'9086981348','June 10th, 2019',3,'pellentesque','Nunc'),(60,'6023542753','December 26th, 2020',1,'cursus,','sit'),(61,'1817825385','March 2nd, 2020',1,'ipsum','Phasellus'),(62,'1222606408','January 2nd, 2020',3,'nec,','nonummy'),(63,'1106888665','December 22nd, 2019',2,'augue','ultrices.'),(64,'4134216940','October 15th, 2019',3,'mollis','Curabitur'),(65,'6722915377','March 5th, 2021',2,'fames','luctus'),(66,'2868915355','November 18th, 2020',2,'orci','ullamcorper'),(67,'4931667842','October 9th, 2019',3,'ut','risus.'),(68,'4986681533','August 15th, 2019',1,'malesuada','sodales'),(69,'5182937325','June 1st, 2019',4,'nunc','diam'),(70,'1306447153','February 9th, 2021',2,'Morbi','tincidunt'),(71,'5669533433','October 10th, 2019',3,'sagittis','quis'),(72,'9864397800','March 22nd, 2021',2,'et','tellus,'),(73,'4057100962','December 10th, 2019',5,'tristique','erat'),(74,'6390942834','October 30th, 2020',3,'Duis','sodales'),(75,'4064873731','March 20th, 2020',5,'enim','Curabitur'),(76,'6591091752','December 3rd, 2019',4,'Nulla','et'),(77,'6400620965','August 7th, 2019',4,'bibendum.','netus'),(78,'7346948462','June 8th, 2019',2,'libero.','neque.'),(79,'1816925914','October 17th, 2020',3,'tempor','blandit'),(80,'6876623228','March 23rd, 2021',4,'orci.','mi.'),(81,'5211958487','July 20th, 2020',1,'nec','lacus.'),(82,'6966162636','March 19th, 2020',4,'non,','vel'),(83,'3877890390','November 23rd, 2020',3,'nostra,','velit'),(84,'5029906119','October 24th, 2019',5,'non,','nunc'),(85,'6018854462','July 29th, 2020',1,'Morbi','convallis'),(86,'3513079718','July 20th, 2019',2,'cursus','gravida.'),(87,'6095129068','August 27th, 2019',5,'tincidunt.','erat.'),(88,'7438303457','July 24th, 2019',5,'quis,','turpis'),(89,'1621643852','July 31st, 2019',2,'metus','ut'),(90,'3210990056','November 6th, 2020',3,'Mauris','parturient'),(91,'9269094376','August 4th, 2020',3,'nec,','vitae,'),(92,'1752218875','June 12th, 2019',1,'enim','sed'),(93,'9217093409','September 9th, 2020',3,'neque','orci'),(94,'4696119545','October 22nd, 2020',3,'sapien.','aptent'),(95,'8348222648','May 31st, 2019',4,'Fusce','erat'),(96,'2915823679','April 11th, 2021',2,'diam','lacinia'),(97,'9465519872','March 28th, 2020',5,'feugiat.','sapien,'),(98,'5258509155','January 20th, 2020',3,'neque','Praesent'),(99,'9895544508','October 28th, 2020',3,'ipsum.','at'),(100,'5507041276','February 7th, 2020',4,'sed,','nulla.');
/*!40000 ALTER TABLE `drivers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:45
