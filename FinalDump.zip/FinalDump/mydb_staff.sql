CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `staff`
--

DROP TABLE IF EXISTS `staff`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `staff` (
  `staffId` int NOT NULL,
  `position` varchar(45) DEFAULT NULL,
  `admin` tinyint DEFAULT NULL,
  PRIMARY KEY (`staffId`),
  UNIQUE KEY `personId_UNIQUE` (`staffId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `staff`
--

LOCK TABLES `staff` WRITE;
/*!40000 ALTER TABLE `staff` DISABLE KEYS */;
INSERT INTO `staff` VALUES (1,'Vivamus',1),(2,'turpis',1),(3,'Aliquam',0),(4,'magna.',1),(5,'elit.',0),(6,'leo.',1),(7,'auctor',1),(8,'tortor.',0),(9,'ullamcorper',1),(10,'a',0),(11,'at',0),(12,'eu',1),(13,'iaculis,',0),(14,'augue',0),(15,'ullamcorper',0),(16,'ac',1),(17,'nisi.',1),(18,'Maecenas',0),(19,'vestibulum',0),(20,'in',1),(21,'egestas.',0),(22,'Donec',1),(23,'Curabitur',0),(24,'eu,',0),(25,'felis.',0),(26,'mus.',0),(27,'diam',0),(28,'eget',0),(29,'tellus',1),(30,'amet',0),(31,'volutpat',1),(32,'lectus',1),(33,'enim',0),(34,'consectetuer',0),(35,'parturient',0),(36,'pede,',0),(37,'eu',0),(38,'imperdiet',1),(39,'magna.',1),(40,'nec,',1),(41,'Proin',0),(42,'Vivamus',0),(43,'ligula',1),(44,'sapien',1),(45,'vulputate,',0),(46,'volutpat',0),(47,'Duis',1),(48,'neque.',1),(49,'mauris,',1),(50,'consequat',0),(51,'nunc',1),(52,'Maecenas',0),(53,'eu',0),(54,'Aenean',0),(55,'tortor.',0),(56,'eget',0),(57,'interdum.',1),(58,'dictum',1),(59,'enim',1),(60,'per',0),(61,'risus',1),(62,'sagittis',1),(63,'interdum',1),(64,'lacus.',0),(65,'penatibus',0),(66,'quis',0),(67,'at,',1),(68,'consequat',0),(69,'nonummy',0),(70,'risus.',0),(71,'et',0),(72,'Suspendisse',0),(73,'in,',1),(74,'tortor.',1),(75,'euismod',0),(76,'velit',1),(77,'mattis',1),(78,'ac',0),(79,'non',1),(80,'sed',0),(81,'in,',1),(82,'commodo',0),(83,'nisi',1),(84,'pharetra.',0),(85,'senectus',0),(86,'ac',1),(87,'non',1),(88,'sit',0),(89,'nisl',1),(90,'congue,',0),(91,'massa',1),(92,'Donec',0),(93,'sit',0),(94,'Cras',0),(95,'lorem',1),(96,'vel',1),(97,'auctor',0),(98,'non',0),(99,'dolor',1),(100,'Aliquam',1);
/*!40000 ALTER TABLE `staff` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:45
