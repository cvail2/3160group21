CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student` (
  `studentId` int NOT NULL,
  `gradYear` int DEFAULT NULL,
  `major` varchar(45) DEFAULT NULL,
  `majorType` varchar(45) DEFAULT NULL,
  `driverId` int DEFAULT NULL,
  PRIMARY KEY (`studentId`),
  UNIQUE KEY `personId_UNIQUE` (`studentId`),
  KEY `driverId` (`driverId`),
  CONSTRAINT `student_ibfk_1` FOREIGN KEY (`driverId`) REFERENCES `drivers` (`driverId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES (201,2021,'lobortis','massa.',NULL),(202,2024,'dignissim','ac,',1),(203,2023,'Nullam','vitae',NULL),(204,2022,'Nulla','egestas',NULL),(205,2023,'Nunc','cursus',NULL),(206,2022,'sociis','scelerisque',15),(207,2024,'feugiat','pede.',NULL),(208,2020,'justo','at',24),(209,2023,'a,','sit',NULL),(210,2020,'fames','Donec',NULL),(211,2020,'feugiat','risus',NULL),(212,2024,'eleifend.','ullamcorper,',NULL),(213,2021,'ac','tempor',NULL),(214,2021,'tincidunt','ligula',NULL),(215,2021,'cursus,','a,',NULL),(216,2024,'magna,','natoque',NULL),(217,2021,'dui','eleifend',NULL),(218,2023,'Sed','malesuada.',NULL),(219,2021,'lorem,','nisi',NULL),(220,2023,'neque','lorem,',53),(221,2021,'suscipit','scelerisque,',NULL),(222,2021,'interdum.','Cras',NULL),(223,2023,'Nulla','quam.',NULL),(224,2020,'sed','hendrerit.',NULL),(225,2022,'nisl.','vestibulum',NULL),(226,2021,'habitant','rhoncus.',42),(227,2024,'Integer','vel',NULL),(228,2023,'enim.','aliquam',NULL),(229,2022,'gravida','commodo',NULL),(230,2024,'urna','mollis.',NULL),(231,2023,'erat.','ipsum',NULL),(232,2020,'egestas','tellus',NULL),(233,2020,'Donec','aliquet,',NULL),(234,2021,'ligula','hendrerit',75),(235,2024,'neque','Proin',NULL),(236,2022,'erat.','Aliquam',49),(237,2022,'ultrices','arcu',NULL),(238,2020,'Sed','sed',NULL),(239,2022,'tincidunt','lacinia.',NULL),(240,2020,'Phasellus','massa.',NULL),(241,2023,'Proin','pede,',NULL),(242,2022,'eu','cursus.',NULL),(243,2023,'mollis','malesuada',NULL),(244,2021,'fames','eget,',NULL),(245,2023,'Praesent','Lorem',NULL),(246,2024,'tristique','eu',69),(247,2020,'pede,','lectus',NULL),(248,2022,'justo','risus.',NULL),(249,2020,'et,','Curabitur',NULL),(250,2024,'malesuada.','vel',NULL),(251,2023,'Donec','est,',NULL),(252,2024,'ipsum','amet',NULL),(253,2022,'Etiam','pede',NULL),(254,2021,'Sed','et',NULL),(255,2022,'ligula.','mus.',NULL),(256,2020,'luctus.','Maecenas',NULL),(257,2024,'nulla.','et,',NULL),(258,2023,'natoque','eu',9),(259,2023,'at','risus.',NULL),(260,2024,'Suspendisse','Suspendisse',NULL),(261,2023,'Nunc','euismod',NULL),(262,2023,'lectus','Nam',NULL),(263,2020,'Cum','neque.',NULL),(264,2023,'eget','odio',NULL),(265,2020,'erat.','Mauris',NULL),(266,2021,'Etiam','Quisque',NULL),(267,2020,'risus.','tristique',NULL),(268,2022,'convallis','dolor',NULL),(269,2021,'Nunc','risus,',NULL),(270,2020,'semper,','sociis',NULL),(271,2021,'Aliquam','Mauris',NULL),(272,2022,'libero.','vel',NULL),(273,2023,'id,','ullamcorper.',12),(274,2022,'sed','ut,',NULL),(275,2024,'sollicitudin','Cras',NULL),(276,2021,'pharetra','lobortis.',NULL),(277,2023,'Maecenas','mauris,',NULL),(278,2021,'scelerisque','convallis',NULL),(279,2020,'nunc','quam',NULL),(280,2023,'sem','lectus.',NULL),(281,2020,'vel','aliquam',NULL),(282,2024,'vel','Cras',NULL),(283,2023,'bibendum','Nam',NULL),(284,2022,'Maecenas','Phasellus',NULL),(285,2021,'tellus.','a,',NULL),(286,2021,'vitae','urna',NULL),(287,2022,'pharetra,','Sed',NULL),(288,2024,'Phasellus','lorem',73),(289,2023,'convallis','velit',NULL),(290,2024,'Sed','montes,',NULL),(291,2024,'purus.','Curabitur',NULL),(292,2024,'pede,','ornare',NULL),(293,2020,'Integer','faucibus',NULL),(294,2022,'est,','Phasellus',NULL),(295,2021,'tellus','massa.',NULL),(296,2021,'consectetuer','primis',NULL),(297,2023,'quam,','in',NULL),(298,2021,'sociosqu','ac',NULL),(299,2020,'gravida.','mattis',NULL),(300,2020,'non','ipsum.',NULL);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:45
