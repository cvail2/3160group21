CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `faculty`
--

DROP TABLE IF EXISTS `faculty`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `faculty` (
  `facultyId` int NOT NULL,
  `title` varchar(45) DEFAULT NULL,
  `highest_degree` varchar(45) DEFAULT NULL,
  `degreeCollege` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`facultyId`),
  UNIQUE KEY `personID_UNIQUE` (`facultyId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `faculty`
--

LOCK TABLES `faculty` WRITE;
/*!40000 ALTER TABLE `faculty` DISABLE KEYS */;
INSERT INTO `faculty` VALUES (1,'sodales','Duis','lobortis'),(2,'fringilla','sed','lorem,'),(3,'dolor','Sed','ut'),(4,'ac','Phasellus','magna'),(5,'ligula.','volutpat','amet'),(6,'ipsum','semper','lacinia'),(7,'orci','ante','venenatis'),(8,'a','Sed','mi.'),(9,'Mauris','fames','malesuada'),(10,'Sed','convallis','metus.'),(11,'neque.','lobortis.','faucibus'),(12,'dictum','nunc','Aenean'),(13,'tincidunt','facilisis.','a,'),(14,'velit.','commodo','fermentum'),(15,'eu','libero.','sem'),(16,'semper','feugiat.','elit,'),(17,'Mauris','risus,','habitant'),(18,'est','ornare','orci'),(19,'nulla.','vehicula','scelerisque,'),(20,'porttitor','vitae','consequat'),(21,'pellentesque','lacus.','Cras'),(22,'Pellentesque','mauris.','id,'),(23,'rutrum','libero','Sed'),(24,'in','elit','lobortis'),(25,'tempus,','sed','Donec'),(26,'amet,','risus','sed,'),(27,'interdum','Nulla','Mauris'),(28,'ridiculus','arcu','erat.'),(29,'nibh','Sed','pede'),(30,'Suspendisse','Donec','sollicitudin'),(31,'natoque','neque.','dictum'),(32,'nunc','augue,','amet'),(33,'Donec','dictum','sed'),(34,'arcu','enim.','a,'),(35,'amet','quis','Etiam'),(36,'elit','est','aliquet'),(37,'Cum','feugiat.','lorem'),(38,'velit.','a,','Nunc'),(39,'felis.','lacinia','aliquam'),(40,'neque','at','Fusce'),(41,'adipiscing,','Phasellus','mattis.'),(42,'nec','risus','lorem'),(43,'non','scelerisque','Cras'),(44,'eu','dapibus','fermentum'),(45,'Ut','molestie','leo,'),(46,'parturient','Aliquam','id,'),(47,'neque.','Sed','tempus'),(48,'gravida','Nullam','ac'),(49,'Morbi','a','at'),(50,'condimentum','libero','elementum,'),(51,'Sed','Phasellus','tempor'),(52,'est','enim','nibh'),(53,'massa.','mollis','sodales'),(54,'erat','adipiscing.','eget'),(55,'magna','magnis','lobortis'),(56,'Integer','Donec','ac'),(57,'egestas','sed','Curae;'),(58,'Nulla','nibh','Phasellus'),(59,'tempor','pede,','a,'),(60,'neque','dolor.','malesuada'),(61,'ut','velit','varius'),(62,'malesuada.','est.','Phasellus'),(63,'faucibus','interdum','Morbi'),(64,'auctor,','ultrices','blandit'),(65,'tincidunt.','mattis','leo.'),(66,'Class','tellus','metus.'),(67,'orci,','risus.','non,'),(68,'In','nisi','magna.'),(69,'Class','venenatis','lacus.'),(70,'sem','Mauris','Quisque'),(71,'parturient','dolor','non,'),(72,'tristique','velit','Pellentesque'),(73,'pede.','semper','Aliquam'),(74,'nonummy','ac','rutrum,'),(75,'ullamcorper,','turpis.','Suspendisse'),(76,'mauris','massa.','molestie.'),(77,'molestie','eget','eget,'),(78,'est','massa','non,'),(79,'Curabitur','sed','porttitor'),(80,'tincidunt','mauris.','Quisque'),(81,'mattis.','at,','nulla'),(82,'non,','sagittis','iaculis'),(83,'metus','Donec','metus'),(84,'Vivamus','cursus','orci'),(85,'iaculis','Nunc','a'),(86,'non,','amet','Suspendisse'),(87,'amet','enim.','nec'),(88,'Aliquam','sed','amet,'),(89,'tincidunt','nunc','posuere'),(90,'augue','arcu.','Fusce'),(91,'id,','Cras','arcu.'),(92,'nascetur','mollis','nibh'),(93,'ultricies','Ut','In'),(94,'dui','est.','orci.'),(95,'mauris','in','velit'),(96,'enim','ipsum','nonummy'),(97,'Nam','nec','Maecenas'),(98,'ac','orci,','Integer'),(99,'enim','quam.','ipsum'),(100,'ornare,','mauris.','enim');
/*!40000 ALTER TABLE `faculty` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:45
