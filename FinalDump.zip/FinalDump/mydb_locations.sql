CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `locations`
--

DROP TABLE IF EXISTS `locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `locations` (
  `locationId` int NOT NULL,
  `locationName` varchar(45) DEFAULT NULL,
  `locationAddress` varchar(45) DEFAULT NULL,
  `food_drop_off_location` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`locationId`),
  UNIQUE KEY `LocationId_UNIQUE` (`locationId`),
  CONSTRAINT `locations_ibfk_1` FOREIGN KEY (`locationId`) REFERENCES `deliveries` (`locationId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `locations`
--

LOCK TABLES `locations` WRITE;
/*!40000 ALTER TABLE `locations` DISABLE KEYS */;
INSERT INTO `locations` VALUES (1,'Vel Nisl PC','4013 Libero Road','6391 Ac Street'),(2,'Sem Semper LLP','596-2492 Id St.','739-3060 Nibh Avenue'),(3,'Auctor Quis Inc.','2882 Molestie Street','2338 Aliquam Rd.'),(4,'Maecenas Iaculis Foundation','Ap #965-2730 Mauris. Rd.','Ap #290-5057 Eu St.'),(5,'Eu Erat Corp.','P.O. Box 705, 2527 Velit Road','P.O. Box 562, 3782 Nisi. Ave'),(6,'Aliquam Rutrum Ltd','7423 Enim Rd.','6755 Ultrices. Ave'),(7,'Iaculis LLP','423-3316 Donec Av.','5921 Lacus. St.'),(8,'Vulputate Velit Company','146 Velit Rd.','5817 Rutrum. Street'),(9,'Nulla Eu Neque Company','P.O. Box 344, 5794 Neque. Road','139-7278 Sagittis. St.'),(10,'Nibh Vulputate Mauris Institute','Ap #432-1987 Aliquet Road','679-9815 Varius. Av.'),(11,'Tortor Nunc Commodo Corporation','640-3168 Magna Av.','Ap #600-1280 Volutpat. Av.'),(12,'Risus Varius Orci LLC','445-3916 Purus, Av.','P.O. Box 717, 5885 Sodales St.'),(13,'Lobortis Inc.','697-1890 Pede Rd.','4890 Ac Rd.'),(14,'In At Limited','6847 Feugiat Road','744 Curabitur Av.'),(15,'Sit Amet Foundation','654-9350 Quam Ave','6129 Ante. Ave'),(16,'Sociis Natoque Institute','1059 Per Rd.','340-4365 Lorem, St.'),(17,'Eget Institute','Ap #398-1736 Condimentum St.','719-4325 Luctus Rd.'),(18,'Nullam Velit Dui Corporation','1011 Orci. Avenue','Ap #185-1714 Orci. Rd.'),(19,'Aliquam Industries','P.O. Box 954, 7704 Dis Rd.','P.O. Box 194, 6800 Mi. Street'),(20,'Egestas Corp.','4781 Aenean Avenue','639-1838 Mauris Street'),(21,'Neque Nullam Corp.','P.O. Box 359, 8520 Accumsan Av.','Ap #640-6673 Non, Rd.'),(22,'Tristique Aliquet Phasellus Industries','6696 Dictum St.','3011 Nullam Rd.'),(23,'Enim Inc.','Ap #157-6721 Velit. St.','9193 Odio Avenue'),(24,'Magnis Dis Parturient Company','8218 Molestie Rd.','9893 Maecenas Road'),(25,'Non Ltd','Ap #260-4367 Commodo Ave','Ap #838-5032 Quis St.'),(26,'Quisque Nonummy LLP','Ap #572-2560 Nunc Av.','P.O. Box 928, 327 Et Road'),(27,'Fusce Mi Limited','P.O. Box 411, 3751 Non, St.','182-8350 Mauris Street'),(28,'In LLP','P.O. Box 817, 5192 Turpis Rd.','6529 Quam Rd.'),(29,'Venenatis Lacus Etiam Corporation','671-1943 Urna, Avenue','Ap #330-177 Pede, Road'),(30,'Enim Company','207 In, Street','270-6919 Ante, Av.'),(31,'Augue Porttitor Associates','Ap #183-5901 Magna Rd.','Ap #783-7918 Pretium Road'),(32,'Morbi Metus Inc.','343-6622 Porttitor Rd.','449-4644 Vel Avenue'),(33,'Ut Inc.','P.O. Box 738, 1656 Convallis Ave','510-5412 Id, Avenue'),(34,'Nonummy Ltd','P.O. Box 396, 3666 Vitae Street','Ap #232-8812 Ac Avenue'),(35,'Vitae Posuere Corporation','P.O. Box 480, 6152 Diam Avenue','7208 Elementum Avenue'),(36,'Lorem Inc.','P.O. Box 681, 3895 Ultrices Rd.','Ap #680-3802 Non St.'),(37,'Justo Nec Ltd','346-3107 Quis Av.','399-5156 Eu, Street'),(38,'Convallis Convallis Dolor Company','861-3322 Nam Avenue','P.O. Box 863, 8320 Pretium St.'),(39,'Donec Incorporated','Ap #508-8467 Diam Ave','278-7924 Interdum. Ave'),(40,'Ut Eros Industries','567-6921 Volutpat. St.','Ap #626-3463 In Av.'),(41,'Phasellus Libero Corporation','630 Quam St.','P.O. Box 277, 5567 Dictum Street'),(42,'Enim Inc.','Ap #805-2523 Nunc St.','Ap #221-4995 Pede. St.'),(43,'Nunc Mauris Incorporated','P.O. Box 552, 2438 Non Avenue','P.O. Box 380, 9795 Odio, Street'),(44,'Aliquam Gravida Mauris Company','P.O. Box 155, 5072 Aliquet Street','724-811 Dis St.'),(45,'Eget Metus In PC','P.O. Box 659, 2080 Tellus. St.','P.O. Box 371, 1759 Vestibulum Rd.'),(46,'Lobortis Foundation','P.O. Box 477, 5686 Ullamcorper. Avenue','P.O. Box 611, 7183 Semper St.'),(47,'Et Commodo At LLP','Ap #500-7779 Ipsum Avenue','P.O. Box 930, 3302 In Rd.'),(48,'Magna Corp.','947-8909 Duis St.','P.O. Box 852, 6109 Suscipit Street'),(49,'Mauris Sagittis Placerat Corp.','1240 Mus. Rd.','537-6407 Arcu Avenue'),(50,'Est Ltd','P.O. Box 628, 8211 Ullamcorper, Avenue','Ap #860-5801 Nunc St.'),(51,'Amet Lorem Semper Associates','694 Non, Av.','Ap #169-7620 Odio Road'),(52,'Orci Sem Eget PC','499-7668 Tellus St.','Ap #272-3836 Ligula Street'),(53,'Ultrices Vivamus Ltd','3445 Felis, St.','Ap #857-3754 Parturient Ave'),(54,'In Foundation','Ap #440-939 Sit Road','P.O. Box 172, 1103 Aliquet. St.'),(55,'Pellentesque LLP','4865 Mattis. Av.','869-9349 Molestie St.'),(56,'Donec Feugiat Metus Foundation','Ap #404-4063 Purus Road','390-7674 Eget Street'),(57,'Aliquet Corporation','Ap #631-5351 Eget Ave','929-503 Phasellus Av.'),(58,'Nam Porttitor Foundation','P.O. Box 612, 7221 Ligula. Ave','Ap #473-6604 Parturient Ave'),(59,'At Sem Foundation','521-9280 In Ave','2324 Class Rd.'),(60,'Enim Gravida Company','P.O. Box 684, 6247 Diam. Street','Ap #736-908 Taciti St.'),(61,'Placerat Institute','768-9433 Vitae Avenue','714-5644 Eros Av.'),(62,'Consectetuer Adipiscing Elit Foundation','832 Cursus. Road','P.O. Box 369, 1018 Mauris, Rd.'),(63,'Elit Foundation','P.O. Box 965, 6284 Arcu. Rd.','158 Duis Rd.'),(64,'Arcu Incorporated','Ap #737-9247 Dui Av.','374-4309 Pede. St.'),(65,'Nunc Incorporated','P.O. Box 429, 3467 Fusce Rd.','Ap #201-8007 Orci, St.'),(66,'Nec Metus Facilisis Consulting','P.O. Box 190, 8594 Dapibus Rd.','779-5814 Eget St.'),(67,'Ac Orci Ut Associates','P.O. Box 713, 8128 Metus. Rd.','1203 Tempus Road'),(68,'Purus Duis Elementum Corporation','680-2447 Nisi St.','5695 Rutrum St.'),(69,'Ultrices Sit Corp.','397-3192 Ultrices St.','Ap #310-6068 Elementum Ave'),(70,'Vivamus Limited','8421 Magna. Avenue','1445 Pede Avenue'),(71,'Luctus Ut LLC','Ap #867-3933 Euismod Av.','3098 Velit. Avenue'),(72,'Lectus Foundation','981-1693 In Av.','Ap #196-6763 Ac, Av.'),(73,'Ullamcorper Institute','P.O. Box 299, 7204 Magnis Ave','Ap #938-9269 Arcu Street'),(74,'Eu Odio Corporation','P.O. Box 487, 3462 Malesuada Ave','7955 Non, Rd.'),(75,'Tellus Faucibus Leo LLC','248-2613 Ornare, Rd.','686-9787 In Road'),(76,'Egestas A Consulting','1199 Pede, St.','P.O. Box 306, 1921 Convallis Avenue'),(77,'Et Pede Nunc Limited','4751 Nonummy Rd.','Ap #775-4515 Neque Street'),(78,'Volutpat Incorporated','361-2243 Lacus. St.','Ap #216-356 Odio St.'),(79,'Ipsum Dolor Sit Corp.','P.O. Box 288, 2465 Ornare Av.','3872 Mauris Road'),(80,'Lacus Etiam Bibendum Consulting','P.O. Box 972, 4925 Mauris Av.','8744 Lorem, Ave'),(81,'Vehicula Et Corporation','418-896 Leo Road','554-4586 Vel St.'),(82,'Sit Inc.','Ap #180-4115 Lorem, Rd.','470-5421 Dui. St.'),(83,'Et Incorporated','914-1338 Suspendisse Avenue','Ap #606-1123 Vel Rd.'),(84,'Libero Mauris Inc.','984-5224 Gravida Road','Ap #934-3851 Nunc Rd.'),(85,'Suspendisse Tristique Neque Associates','Ap #308-7854 In, Avenue','8978 Cursus Av.'),(86,'Facilisis Ltd','4353 Lorem Rd.','216-5919 Fringilla Road'),(87,'Proin Vel Consulting','7992 Ipsum St.','573-9523 Tristique Avenue'),(88,'Mauris Elit Dictum LLC','Ap #670-6790 Velit St.','P.O. Box 619, 6695 In St.'),(89,'Tristique Pellentesque Corp.','4272 Laoreet St.','905-1119 Est. Av.'),(90,'Nec Urna Et Corporation','2105 Rutrum Ave','P.O. Box 360, 4094 Lacus. Avenue'),(91,'Mauris Sapien Cursus Company','7139 Duis Avenue','5163 Aliquam Rd.'),(92,'Nam Porttitor Ltd','Ap #641-9977 Cras Rd.','7316 Rutrum Rd.'),(93,'Consectetuer Limited','Ap #917-9438 Ut St.','973-3081 Dolor Road'),(94,'Sapien Cras Dolor Industries','7419 Magnis Road','180-1105 Morbi Ave'),(95,'Sit Amet LLP','P.O. Box 742, 7119 Sed Street','7411 Dictum Ave'),(96,'Nonummy Ipsum Limited','P.O. Box 989, 4927 Sociis Ave','Ap #353-9312 Elit, Street'),(97,'Libero Mauris Aliquam Limited','719-9211 Elementum, St.','718-5065 A, Rd.'),(98,'Nibh Phasellus Associates','636-1985 Convallis Street','Ap #882-523 Eu Av.'),(99,'Sed Auctor Odio Ltd','Ap #257-6015 Lectus. Rd.','602-2636 Nam Street'),(100,'Sapien Aenean Massa Company','P.O. Box 362, 3053 Tellus. Av.','997-1009 Aliquam Av.');
/*!40000 ALTER TABLE `locations` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:12:45
