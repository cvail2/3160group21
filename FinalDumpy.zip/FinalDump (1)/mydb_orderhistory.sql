CREATE DATABASE  IF NOT EXISTS `mydb` /*!40100 DEFAULT CHARACTER SET utf8 */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `mydb`;
-- MySQL dump 10.13  Distrib 8.0.20, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: mydb
-- ------------------------------------------------------
-- Server version	8.0.20

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `orderhistory`
--

DROP TABLE IF EXISTS `orderhistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `orderhistory` (
  `orderId` int NOT NULL,
  `price` double DEFAULT NULL,
  `driverId` int DEFAULT NULL,
  `restaurantId` int DEFAULT NULL,
  `orderDetails` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`orderId`),
  UNIQUE KEY `orderId_UNIQUE` (`orderId`),
  KEY `driverId` (`driverId`),
  KEY `restaurantId` (`restaurantId`),
  CONSTRAINT `orderhistory_ibfk_1` FOREIGN KEY (`driverId`) REFERENCES `drivers` (`driverId`),
  CONSTRAINT `orderhistory_ibfk_2` FOREIGN KEY (`restaurantId`) REFERENCES `restaurants` (`restaurantId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `orderhistory`
--

LOCK TABLES `orderhistory` WRITE;
/*!40000 ALTER TABLE `orderhistory` DISABLE KEYS */;
INSERT INTO `orderhistory` VALUES (1,99.56,1,1,'risus.'),(2,34.49,2,2,'diam.'),(3,19.64,3,3,'dolor'),(4,29.78,4,4,'penatibus'),(5,27.9,5,5,'neque'),(6,19.05,6,6,'sit'),(7,44.66,7,7,'est.'),(8,79.65,8,8,'mi'),(9,57.97,9,9,'eu'),(10,14.1,10,10,'magnis'),(11,72.97,11,11,'Fusce'),(12,41.26,12,12,'Aliquam'),(13,38.7,13,13,'luctus'),(14,13.65,14,14,'neque'),(15,49.85,15,15,'Fusce'),(16,62.91,16,16,'risus.'),(17,18.46,17,17,'a,'),(18,15.12,18,18,'Vivamus'),(19,23.46,19,19,'elit'),(20,67.88,20,20,'eget,'),(21,90.67,21,21,'Cum'),(22,64.06,22,22,'non'),(23,19.4,23,23,'luctus'),(24,89.27,24,24,'turpis.'),(25,6.4,25,25,'Cras'),(26,77.89,26,26,'malesuada'),(27,38.72,27,27,'egestas.'),(28,1.21,28,28,'ultrices.'),(29,66.29,29,29,'lorem'),(30,65.79,30,30,'Aliquam'),(31,59.67,31,31,'rutrum'),(32,47.98,32,32,'mi'),(33,91.87,33,33,'mattis'),(34,48.52,34,34,'parturient'),(35,78.49,35,35,'sollicitudin'),(36,44.19,36,36,'Cum'),(37,95.68,37,37,'sed'),(38,22.98,38,38,'Mauris'),(39,99.55,39,39,'massa.'),(40,94.52,40,40,'nisi.'),(41,5.91,41,41,'libero'),(42,91.32,42,42,'vehicula'),(43,58.12,43,43,'inceptos'),(44,60.18,44,44,'sagittis'),(45,44.81,45,45,'libero'),(46,53.71,46,46,'ultricies'),(47,91.49,47,47,'mattis.'),(48,52.5,48,48,'Aenean'),(49,36.64,49,49,'adipiscing'),(50,35.63,50,50,'cursus'),(51,66.64,51,51,'et'),(52,67.18,52,52,'sit'),(53,55.63,53,53,'pede.'),(54,80.54,54,54,'vulputate'),(55,5.31,55,55,'sit'),(56,93.16,56,56,'Donec'),(57,98.85,57,57,'Duis'),(58,2.68,58,58,'ultrices,'),(59,33.34,59,59,'montes,'),(60,56.04,60,60,'Mauris'),(61,38.24,61,61,'eget,'),(62,35.57,62,62,'bibendum'),(63,81.29,63,63,'Nulla'),(64,19.41,64,64,'lectus'),(65,93.17,65,65,'ipsum'),(66,4.52,66,66,'tempus,'),(67,46.58,67,67,'libero'),(68,99.56,68,68,'auctor'),(69,24.67,69,69,'faucibus'),(70,54.36,70,70,'aptent'),(71,25.53,71,71,'Integer'),(72,51.34,72,72,'sagittis'),(73,24.53,73,73,'sem'),(74,41.74,74,74,'viverra.'),(75,97.59,75,75,'quam.'),(76,4.17,76,76,'at'),(77,23.5,77,77,'orci,'),(78,89.94,78,78,'porttitor'),(79,17.8,79,79,'vulputate,'),(80,51.68,80,80,'fringilla'),(81,95.28,81,81,'vestibulum'),(82,54.82,82,82,'Proin'),(83,85.77,83,83,'In'),(84,80.03,84,84,'scelerisque'),(85,42.18,85,85,'litora'),(86,51.63,86,86,'a,'),(87,10.15,87,87,'dolor'),(88,10.51,88,88,'at'),(89,92.8,89,89,'accumsan'),(90,91.65,90,90,'neque'),(91,89.72,91,91,'Pellentesque'),(92,91.41,92,92,'Donec'),(93,83.82,93,93,'Donec'),(94,26.38,94,94,'nunc'),(95,57.23,95,95,'dui.'),(96,15.34,96,96,'Cras'),(97,89.39,97,97,'neque'),(98,58.34,98,98,'amet'),(99,87.47,99,99,'magnis'),(100,97.6,100,100,'dapibus');
/*!40000 ALTER TABLE `orderhistory` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-05-05 16:29:46
